// File: AdapterPatternExample.java
public class AdapterPatternExample {
    public static void main(String[] args) {
        // Create instances of the third-party gateways
        PayPalGateway payPalGateway = new PayPalGateway();
        StripeGateway stripeGateway = new StripeGateway();

        // Create adapters for the gateways
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPalGateway);
        PaymentProcessor stripeAdapter = new StripeAdapter(stripeGateway);

        // Use the adapters to process payments
        System.out.println("Processing payment using PayPal adapter:");
        payPalAdapter.processPayment(100.0);

        System.out.println("\nProcessing payment using Stripe adapter:");
        stripeAdapter.processPayment(200.0);
    }
}

