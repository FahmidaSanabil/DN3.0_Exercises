// File: MVCPatternExample.java
public class MVCPatternExample {
    public static void main(String[] args) {
        // Create a student model
        Student student = new Student("1", "Zara", "A");

        // Create a student view
        StudentView view = new StudentView();

        // Create a student controller
        StudentController controller = new StudentController(student, view);

        // Update the view with the initial student details
        controller.updateView();

        // Modify the student details through the controller
        controller.setStudentName("Zara");
        controller.setStudentGrade("B");

        // Update the view with the new student details
        controller.updateView();
    }
}
