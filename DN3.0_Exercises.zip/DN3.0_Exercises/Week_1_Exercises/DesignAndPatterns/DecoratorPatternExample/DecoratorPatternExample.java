// File: DecoratorPatternExample.java
public class DecoratorPatternExample {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        Notifier emailAndSMSNotifier = new SMSNotifierDecorator(emailNotifier);
        Notifier emailSMSAndSlackNotifier = new SlackNotifierDecorator(emailAndSMSNotifier);

        String message = "Hello!!!";

        System.out.println("Sending via Email only:");
        emailNotifier.send(message);

        System.out.println("\nSending via Email and SMS:");
        emailAndSMSNotifier.send(message);

        System.out.println("\nSending via Email, SMS, and Slack:");
        emailSMSAndSlackNotifier.send(message);
    }
}

