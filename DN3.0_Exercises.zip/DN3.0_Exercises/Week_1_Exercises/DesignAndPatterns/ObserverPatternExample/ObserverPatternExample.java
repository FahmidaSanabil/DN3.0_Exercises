// File: ObserverPatternExample.java
public class ObserverPatternExample {
    public static void main(String[] args) {
        // Create stock market
        StockMarket appleStock = new StockMarket("Apple", 150.00);

        // Create observers
        Observer mobileApp = new MobileApp("MobileApp");
        Observer webApp = new WebApp("WebApp");

        // Register observers
        appleStock.registerObserver(mobileApp);
        appleStock.registerObserver(webApp);

        // Update stock price and notify observers
        appleStock.setStockPrice(155.00);

        // Deregister one observer and update stock price
        appleStock.deregisterObserver(webApp);
        appleStock.setStockPrice(160.00);
    }
}
