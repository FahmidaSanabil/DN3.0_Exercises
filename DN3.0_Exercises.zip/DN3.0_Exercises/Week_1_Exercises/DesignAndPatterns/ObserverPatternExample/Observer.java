// File: Observer.java
public interface Observer {
    void update(String stockName, double stockPrice);
}
