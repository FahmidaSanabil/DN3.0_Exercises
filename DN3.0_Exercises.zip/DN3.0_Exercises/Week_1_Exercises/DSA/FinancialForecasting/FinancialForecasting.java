// File: FinancialForecasting.java
public class FinancialForecasting {

    // Recursive method to calculate future value
    public static double calculateFutureValue(double principal, double growthRate, int years) {
        // Base case: If the number of years is 0, return the principal
        if (years == 0) {
            return principal;
        }
        // Recursive case: Calculate the future value for the next year
        return calculateFutureValue(principal * (1 + growthRate), growthRate, years - 1);
    }

    public static void main(String[] args) {
        double principal = 1000.0; // Initial amount
        double growthRate = 0.07; // 5% growth rate
        int years = 7; // Number of years

        double futureValue = calculateFutureValue(principal, growthRate, years);
        System.out.printf("The future value of the investment after %d years is: $%.2f%n", years, futureValue);
    }
}
