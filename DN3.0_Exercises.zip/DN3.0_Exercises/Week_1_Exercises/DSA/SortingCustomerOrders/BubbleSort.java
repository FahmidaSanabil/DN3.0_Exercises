import java.util.Arrays;

public class BubbleSort {
    public static void bubbleSort(Order[] orders) {
        int n = orders.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (orders[j].getTotalPrice() > orders[j + 1].getTotalPrice()) {
                    // Swap orders[j] and orders[j+1]
                    Order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                }
            }
        }
    }

    public static void main(String[] args) {
        Order[] orders = {
            new Order(1, "Hasan", 167.0),
            new Order(2, "Zara", 230.0),
            new Order(3, "Jeff", 224.0)
        };

        bubbleSort(orders);
        System.out.println(Arrays.toString(orders));
    }
}
