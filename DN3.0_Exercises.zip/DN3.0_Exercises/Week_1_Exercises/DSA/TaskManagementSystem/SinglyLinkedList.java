public class SinglyLinkedList {
    private Node head;

    private class Node {
        Task task;
        Node next;

        Node(Task task) {
            this.task = task;
            this.next = null;
        }
    }

    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public boolean searchTask(int taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.getTaskId() == taskId) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    public boolean deleteTask(int taskId) {
        if (head == null) return false;

        if (head.task.getTaskId() == taskId) {
            head = head.next;
            return true;
        }

        Node current = head;
        while (current.next != null && current.next.task.getTaskId() != taskId) {
            current = current.next;
        }

        if (current.next == null) return false;

        current.next = current.next.next;
        return true;
    }

    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();
        list.addTask(new Task(1, "Task 1", "Pending"));
        list.addTask(new Task(2, "Task 2", "Completed"));
        list.addTask(new Task(3, "Task 3", "In Progress"));

        System.out.println("Tasks in list:");
        list.traverseTasks();

        System.out.println("\nDeleting Task 2...");
        list.deleteTask(2);

        System.out.println("\nTasks in list after deletion:");
        list.traverseTasks();

        System.out.println("\nSearching for Task 3: " + list.searchTask(3));
    }
}
