// File: EmployeeManagement.java
public class EmployeeManagement {
    private Employee[] employees;
    private int size;

    public EmployeeManagement(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }

    public void addEmployee(Employee employee) {
        if (size < employees.length) {
            employees[size++] = employee;
        } else {
            System.out.println("Array is full. Cannot add more employees.");
        }
    }

    public Employee searchEmployeeById(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null; // Employee not found
    }

    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    public boolean deleteEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                // Shift elements to fill the gap
                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[--size] = null; // Avoid memory leak
                return true; // Employee deleted
            }
        }
        return false; // Employee not found
    }

    public static void main(String[] args) {
        EmployeeManagement em = new EmployeeManagement(5);

        em.addEmployee(new Employee(1, "Aliya", "Developer", 70000));
        em.addEmployee(new Employee(2, "Zara", "Manager", 85000));
        em.addEmployee(new Employee(3, "Nithu", "Designer", 60000));

        System.out.println("All employees:");
        em.traverseEmployees();

        System.out.println("\nSearching for employee with ID 2:");
        System.out.println(em.searchEmployeeById(2));

        System.out.println("\nDeleting employee with ID 1...");
        em.deleteEmployee(1);

        System.out.println("\nAll employees after deletion:");
        em.traverseEmployees();
    }
}
