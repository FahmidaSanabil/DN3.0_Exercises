// File: LibraryManagementBinarySearch.java
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class LibBinarySearch {

    public static Book binarySearchByTitle(List<Book> books, String title) {
        int low = 0;
        int high = books.size() - 1;

        while (low <= high) {
            int mid = (low + high) / 2;
            Book midBook = books.get(mid);
            int comparison = midBook.getTitle().compareToIgnoreCase(title);

            if (comparison == 0) {
                return midBook;
            } else if (comparison < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return null; // Book not found
    }

    public static void main(String[] args) {
        List<Book> books = Arrays.asList(
            new Book(1, "The Unexpected Guest", "Agatha Christie"),
            new Book(2, "Grey's Anatomy", "Meredith Grey"),
            new Book(3, "Lucifer", "Leo")
        );

        // Sort the list by title for binary search
        books.sort(Comparator.comparing(Book::getTitle));

        System.out.println("Searching for 'Grey's Anatomy': " + binarySearchByTitle(books, "Grey's Anatomy"));
    }
}
